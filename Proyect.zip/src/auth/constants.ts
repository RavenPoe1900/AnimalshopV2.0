export const jwtConstants = {
  secret: 'umtopima@1=,34,sdfe.',
};